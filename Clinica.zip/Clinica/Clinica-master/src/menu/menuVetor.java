package menu;

import java.time.LocalDate;
import java.util.Scanner;

import csv.CSVFile;
import medicamento.Medicamento;
import paciente.Paciente;
import vetor.MedicamentoDAOVetor;
import vetor.PacienteDAOVetor;

public class menuVetor {
	CSVFile<Paciente> pacienteCSV = new CSVFile<>();
	CSVFile<Medicamento> medicamentoCSV = new CSVFile<>();
	MedicamentoDAOVetor medicamentosVetor = new MedicamentoDAOVetor();
	PacienteDAOVetor pacientesVetor = new PacienteDAOVetor();
	Scanner in = new Scanner(System.in);
	int op = 1;
	
	public void carrega(){
		System.out.println("--> Vetor <--");
		do {
			System.out
					.println("Voce deseja trabalhar nos medicamentos ou pacientes? \n(Digite sair para finalizar o programa)");
			switch (in.next().toLowerCase()) {
			case "pacientes":
				Paciente p;
				pacientesVetor.loadData(pacienteCSV);
				do {
					System.out.println("=>Paciente");
					System.out.println("1 - Listar");
					System.out.println("2 - Cadastrar");
					System.out.println("3 - Remover");
					System.out.println("4 - Pesquisar");
					System.out.println("0 - Sair");
					switch (in.nextInt()) {
					case 1:
						System.out.println(pacientesVetor.toString());
						break;
					case 2:
						p = new Paciente();
						in.nextLine();
						System.out
								.println("Digite o nome do Paciente:");
						p.setNome(in.nextLine());
						System.out.println("Digite o RG do Paciente: ");
						p.setRG(in.next());
						in.nextLine();
						System.out
								.println("Digite a data de aniversario do Paciente:");
						p.setDataNascimento(LocalDate.parse(in
								.nextLine()));
	
						pacientesVetor.addPaciente(p);
						System.out.println(pacientesVetor.getPaciente(p
								.getRG()));
	
						break;
					case 3:
						p = new Paciente();
						System.out
								.println("Digite o RG ou o Nome do Paciente:");
						p = pacientesVetor.getPaciente(in.next()
								.toUpperCase());
	
						System.out
								.println("Tem certeza que quer deletar o paciente:\n"
										+ p);
						System.out
								.println("Digite sim para deletar (qualquer outro comando para cancelar):");
						if (in.next().toLowerCase().equals("sim")) {
							pacientesVetor.removePaciente(p.getRG());
						} else {
							System.out
									.println("A remocao nao ocorreu!");
						}
						break;
					case 4:
						System.out
								.println("Digite o RG ou o Nome do Paciente:");
						System.out.println(pacientesVetor
								.getPaciente(in.next().toUpperCase()));
						break;
					case 0:
						op = 0;
						break;
					default:
						System.out.println("Operacao invalida!");
						break;
					}
				} while (op == 1);
				op = 1;
				break;
			case "medicamentos":
				Medicamento m;
				medicamentosVetor.loadData(medicamentoCSV);
				do {
					System.out.println("=>Medicamento");
					System.out.println("1 - Listar");
					System.out.println("2 - Cadastrar");
					System.out.println("3 - Remover");
					System.out.println("4 - Pesquisar");
					System.out.println("0 - Sair");
					switch (in.nextInt()) {
					case 1:
						System.out
								.println(medicamentosVetor.toString());
						break;
					case 2:
						m = new Medicamento();
						in.nextLine();
						System.out
								.println("Digite o nome do Medicamento:");
						m.setNome(in.nextLine());
						System.out
								.println("Digite o Codigo do Medicamento: ");
						m.setCode(in.next());
	
						medicamentosVetor.addMedicamento(m);
						System.out.println(medicamentosVetor
								.getMedicamento(m.getCode()));
	
						break;
					case 3:
						m = new Medicamento();
						System.out
								.println("Digite o Codigo ou o Nome do Medicamento:");
						m = medicamentosVetor.getMedicamento(in.next()
								.toUpperCase());
	
						System.out
								.println("Tem certeza que quer deletar o Medicamento:\n"
										+ m);
						System.out
								.println("Digite sim para deletar (qualquer outro comando para cancelar):");
						if (in.next().toLowerCase().equals("sim")) {
							medicamentosVetor.removeMedicamento(m
									.getCode());
						} else {
							System.out
									.println("A remocao nao ocorreu!");
						}
						break;
					case 4:
						System.out
								.println("Digite o Codigo ou o Nome do Medicamento:");
						System.out
								.println(medicamentosVetor
										.getMedicamento(in.next()
												.toUpperCase()));
						break;
					case 0:
						op = 0;
						break;
					default:
						System.out.println("Operacao invalida!");
						break;
					}
				} while (op == 1);
				op = 1;
				break;
			case "sair":
				System.exit(0);
			default:
				System.out.println("Opcao invalida!");
				break;
			}
		} while (1 == 1);
	}
}
