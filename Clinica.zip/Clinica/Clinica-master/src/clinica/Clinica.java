/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinica;

import java.util.Scanner;

import menu.menuLista;
import menu.menuVetor;


/**
 *
 * @author reque
 */
public class Clinica {

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String[] args) {
		/*
		 * Selection Sort para o Vetor , e Insertion Sort para a Lista
		 */
		Scanner in = new Scanner(System.in);
		menuLista ml = new menuLista();
		menuVetor mv = new menuVetor();
		

		do {
			System.out.println("Digite Vetor ou Lista para escolher sua opcao? \n(Digite sair para finalizar o programa)");
			switch (in.next().toLowerCase()) {
			case "vetor":
				mv.carrega();
			case "lista":
				ml.carrega();
			case "sair":
				System.exit(0);
			default:
				System.out.println("Opcao invalida!");

				break;
			}
		} while (1 == 1);

	}

}
